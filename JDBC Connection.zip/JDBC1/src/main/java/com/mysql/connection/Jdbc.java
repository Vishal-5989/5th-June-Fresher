package com.mysql.connection;

import java.sql.*;
import java.util.Scanner;

public class Jdbc {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter value 1:Insert 2:Delete 3:Update");
        int a=sc.nextInt();
        switch (a) {
            case 1:
            try {
                System.out.println("Enter values to insert: ");
                System.out.println("Enter emp_id: ");
                int x=sc.nextInt();
                System.out.println("Enter Emp Name: ");
                String y=sc.next();
                System.out.println("Enter Emp city: ");
                String z=sc.next();
                System.out.println("Enter Emp blood grp: ");
                String n=sc.next();
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc", "root", "Tiger");
                PreparedStatement ps = conn.prepareStatement("insert into emp values(?,?,?,?)");
                ps.setInt(1, x);
                ps.setString(2, y);
                ps.setString(3, z);
                ps.setString(4, n);
                ps.executeUpdate();
                System.out.println("Data Inserted Successful");
            } catch (ClassNotFoundException ex) {
                ex.printStackTrace();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            break;
            case 2:
                try {
                    System.out.println("Enter emp_id: ");
                    int m=sc.nextInt();
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc", "root", "Tiger");
                    PreparedStatement ps = conn.prepareStatement("delete from emp where emp_id=?");
                        ps.setInt(1,m);
                        ps.executeUpdate();
                    System.out.println("Data deleted");
                    conn.close();
                } catch (ClassNotFoundException ex) {
                    ex.printStackTrace();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
                break;
            case 3:
                try {
                    System.out.println("Enter emp_id: ");
                    int o=sc.nextInt();
                    System.out.println("Enter Updated blood group: ");
                    String p=sc.next();
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc", "root", "Tiger");
                    PreparedStatement ps = conn.prepareStatement("update emp set bloodgrp=? where emp_id=?");
                    ps.setString(1,p);
                    ps.setInt(2,o);
                    ps.executeUpdate();
                    System.out.println("Data Updated");
                    conn.close();
                } catch (ClassNotFoundException ex) {
                    ex.printStackTrace();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
                break;
            default:
                System.out.println("Incorrect choice");
                break;
        }
    }
}
