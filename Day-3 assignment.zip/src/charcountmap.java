import java.util.HashMap;
import java.util.Map;

public class charcountmap {
    public static void main(String[] args) {

        String str="selfless good deed";
        HashMap<Character,Integer>map=new HashMap<>();
        for (char c: str.toCharArray())
        {
          map.put(c,map.getOrDefault(c,0)+1);
        }
        for(Map.Entry<Character,Integer>l:map.entrySet())
        {
            System.out.println("Character= "+l.getKey()+ " "+l.getValue()+ "Times");
        }
  }
}
