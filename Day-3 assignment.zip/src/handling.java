import java.util.*;
public class handling {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int i=1;
        System.out.println("enter 1.ArithmeticException  2.NullPointerException 3.NumberFormat Exception 4.ArrayIndexOutOfBoundsException 5.StringIndexOutOfBoundsException 6.Catch Multiple Exceptions 7.nested try 8.finally block 9.exit");
       while (i>0)
       {
        System.out.println("  Enter the choice: ");
        int choice=sc.nextInt();

        switch(choice) {
            case 1:
                try {
                    int data = 100 / 0;
                } catch (ArithmeticException e) {
                    System.out.println(e);
                }
                System.out.println("rest of the code...");
                break;
            case 2:
                String ptr = null;
                try {
                    if ("gfg".equals(ptr))
                        System.out.println("Same");
                    else
                        System.out.println(" Not Same");
                } catch (NullPointerException e) {
                    System.out.print("Caught NullPointerException");
                }

                break;
            case 3:
                try {
                    int a = Integer.parseInt("1a");
                    System.out.println(a);
                } catch (NumberFormatException nfe) {
                    System.out.println("NumberFormat Exception: invalid input string");
                }
                System.out.println("Continuing execution...");
                break;
            case 4:
                 int[] numbers = {1, 2, 3, 4, 5};
                 try {
                 int x = numbers[5]; // this will throw an ArrayIndexOutOfBoundsException
                 System.out.println(x);
                 } catch (ArrayIndexOutOfBoundsException e) {
                     System.out.println("Error: Index is out of bounds.");
                }
                 break;

            case 5:
                String str = "My String";
                try {
                    System.out.println(str.charAt(9));
                } catch(StringIndexOutOfBoundsException e) {
                    System.out.println("String index out of bounds. String length: " + str.length());
                }
                break;
            case 6:
                try{
                    int a[]=new int[5];
                    a[5]=30/0;
                    System.out.println(a[10]);
                }
                catch(ArithmeticException e)
                {
                    System.out.println("Arithmetic Exception occurs");
                }
                catch(ArrayIndexOutOfBoundsException e)
                {
                    System.out.println("ArrayIndexOutOfBounds Exception occurs");
                }
                catch(Exception e)
                {
                    System.out.println("Parent Exception occurs");
                }
                System.out.println("rest of the code");
                break;

            case 7:
                try {
                    try {
                        try {
                            int arr[] = { 1, 2, 3, 4 };
                            System.out.println(arr[10]);
                        }
                catch (ArithmeticException e) {
                System.out.println("Arithmetic exception");
                System.out.println(" inner try block 2");
                 }
                 }
                catch (ArithmeticException e) {
                 System.out.println("Arithmetic exception");
                 System.out.println("inner try block 1");
                    }
                  }
                catch (ArrayIndexOutOfBoundsException e4) {
                System.out.print(e4);
                System.out.println(" outer (main) try block");
                }
                    catch (Exception e5) {
                    System.out.print("Exception");
                    System.out.println(" handled in main try-block");
                }
                break;
            case 8:

                try {

                    System.out.println("Inside the try block");

                    //below code throws divide by zero exception
                    int data=25/0;
                    System.out.println(data);
                }
                //cannot handle Arithmetic type exception
                //can only accept Null Pointer type exception
                catch(NullPointerException e){
                    System.out.println(e);
                }

                //executes regardless of exception occured or not
                finally {
                    System.out.println("finally block is always executed");
                }

                System.out.println("rest of the code...");
                break;
            case 9:
                System.exit(0);
                break;

            default:
                System.out.println("YOU HAVE ENTERED WRONG CHOICE: ");
        }
    }}
}
