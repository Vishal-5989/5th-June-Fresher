import java.util.*;
public class Stringc {
    public static void main(String[] args) {

            String [] a ={"(AS,DF)","(RT,DF)","(AS,DF)","(RT,DF)","(NM,CV)","(VB,NM)","(VB,NM)","(JK,LH)","(AS,DF)"};


            for(int i=0;i<a.length;i++)
            {
                int count=1;
                for(int j=i+1;j<a.length;j++)
                {
                    if(a[i].equals(a[j]))
                   {
                       count++;
                   }
                }
                if(count>1)
                System.out.println(a[i] + count);

                }

            }
    }

