public class PrimeNum {
    public static void main(String[] args) {
        String primenum=" ";
        int count=0;
        for(int i=1;i<=1000;i++)
        {
            int con=0;
            for(int num=i;num>=1;num--)
            {
                if(i%num==0)
                {
                    con=con+1;
                }
            }
            if(con==2)
            {
                primenum=primenum+i+" ";
                count++;
            }
        }
        System.out.println("Prime Numbers from 1 to 1000 are "+ primenum +" ");
        System.out.println("Count is :"+ count);
    }
}
