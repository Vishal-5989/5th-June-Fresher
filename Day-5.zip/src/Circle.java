import java.util.Scanner;
public class Circle {
    final double pi =3.14;
    public static void main(String[] args) {
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter the radius: ");
            double radius=sc.nextDouble();
            Circle cr=new Circle();
            int i=1;
            while(i>0) {
                System.out.println("Enter 1. Area 2.circumference 3. exit ");
                System.out.println("Enter your choice : ");
                int op = sc.nextInt();
                switch (op) {
                    case 1:
                        cr.area(radius);
                        break;

                    case 2:
                        cr.circumference(radius);
                        break;

                    case 3:
                        System.exit(0);
                        break;

                    default:
                        System.out.println("You have entered wrong choice.");

                }
            }
    }
    public void area(double r )
    {
        double area=pi*r*r;
        System.out.println("Area of Circle: "+ area);
    }

    public void circumference(double r )
    {
        double c=2*pi*r;
        System.out.println("Circumference of Circle : "+ c);
    }

}
