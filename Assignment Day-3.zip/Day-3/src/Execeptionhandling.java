import java.util.Scanner;

public class Execeptionhandling {
    public static void main(String[] args) {
       Scanner sc=new Scanner(System.in);
        System.out.println("Enter 1:Arithmatic Exception 2:Null Pointer Exception 3:Number Format Exception 4:Array Index Out Of Bounds Exception 5:String Index Out Of Bounds Exception 6:Multiple catch statement 7:Nested try block 8:Finally block 9:Exit");
       int i=1;
        while (i > 0) {
            System.out.println("Enter the value: ");
            int a = sc.nextInt();
            switch (a) {
                case 1:
                    try {
                        int data = 100 / 0;
                    } catch (ArithmeticException e) {
                        System.out.println(e);
                    }
                    break;
                case 2:
                    try {
                        String s = null;
                        System.out.println(s.length());
                    } catch (NullPointerException n) {
                        System.out.println(n);
                    }
                    break;
                case 3:
                    try {
                        String s1 = "Kakashi";
                        int m = Integer.parseInt(s1);
                    } catch (NumberFormatException n1) {
                        System.out.println(n1);
                    }
                    break;
                case 4:
                    try {
                        int b[] = new int[5];
                        b[10] = 50;
                    } catch (ArrayIndexOutOfBoundsException a1) {
                        System.out.println(a1);
                    }
                    break;
                case 5:
                    String s2 = "Naruto";
                    try {
                        String substring = s2.substring(2, 8);
                    } catch (StringIndexOutOfBoundsException a2) {
                        System.out.println(a2);
                    }
                    break;
                case 6:
                    try {
                        String s = null;
                        System.out.println(s.length());
                    } catch (ArithmeticException s1) {
                        System.out.println("Arithmetic Exception occurs " + s1);
                    } catch (ArrayIndexOutOfBoundsException s3) {
                        System.out.println("ArrayIndexOutOfBounds Exception occurs " + s3);
                    } catch (Exception s4) {
                        System.out.println("Parent Exception occurs" + s4);
                    }
                    break;
                case 7:
                    try {
                        try {
                            try {
                                int arr[] = {1, 7, 2, 0, 28, 6};
                                System.out.println(arr[15]);
                            } catch (ArithmeticException arr1) {
                                System.out.println("Arithmetic exception " + arr1);
                                System.out.println("block 2");
                            }
                        } catch (ArithmeticException arr2) {
                            System.out.println("Arithmetic exception " + arr2);
                            System.out.println("block 1");
                        }
                    } catch (ArrayIndexOutOfBoundsException arr3) {
                        System.out.print("Array Index Out Of Bounds Exception " + arr3);
                        System.out.println(" outer (main) try block");
                    } catch (Exception arr4) {
                        System.out.print("Exception " + arr4);
                        System.out.println(" handled in main try-block");
                    }
                    break;
                case 8:
                    try {
                        int data = 15 / 0;
                        System.out.println(data);
                    } catch (ArrayIndexOutOfBoundsException data1) {
                        System.out.println("Exception handled " + data1);
                    } finally {
                        System.out.println("finally block");
                    }
                    break;
                case 9:
                    System.exit(0);
                    break;
                default:
                    System.out.println("wrong value");
                    break;
            }
        }
    }
}
