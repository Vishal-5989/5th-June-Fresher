import java.util.*;
public class Hashmapcount {
    public static void main(String[] args) {
       String s="Neutrino Tech labs";
        HashMap<Character, Integer> charCountMap
                = new HashMap<Character, Integer>();
        char[] s1 = s.toCharArray();
        for(char c:s1)
        {
            charCountMap.put(c, charCountMap.getOrDefault(c,0)+1);
        }
        for(Map.Entry<Character,Integer>l: charCountMap.entrySet())
        {
            System.out.println("Character= "+l.getKey()+" "+l.getValue()+" Times");
        }

    }
}
