import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class Filehandling {
    public static void Createfile() {
        try {
            File f = new File("C:\\Users\\NTS-Anuli Kadam\\Documents\\Filehandling.txt");
            if (f.createNewFile()) {
                System.out.println("File is created successfully.");
            } else {
                System.out.println("File is already exist");
            }
        } catch (IOException exception) {
            System.out.println("An unexpected error is occurred.");
        }
    }

    public static void Writeinfile() {
        try {
            FileWriter f1 = new FileWriter("C:\\Users\\NTS-Anuli Kadam\\Documents\\Filehandling.txt");
            f1.write("Wake up to reality!!!Nothing ever goes as planned in this accursed world.The longer you live, the more you realize that te only things that truly exist in this reality are merely pain ~~Madara Uchhiha");
            System.out.println("Statement added successfully");
            f1.close();
        } catch (IOException e) {
            System.out.println("Error");
        }
    }

    public static void Readfromfile() {
        try {
            File f2 = new File("C:\\Users\\NTS-Anuli Kadam\\Documents\\Filehandling.txt");
            Scanner s = new Scanner(f2);
            while (s.hasNextLine()) {
                String fileData = s.nextLine();
                System.out.println(fileData);
            }
            s.close();

        } catch (FileNotFoundException exception) {
            System.out.println("Unexcpected error occurred!");
            exception.printStackTrace();
        }


    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println(" 1:Write in file 2:Read from the file -----Enter your choice1");
        int a = sc.nextInt();
        Createfile();
            switch (a) {
                case 1:
                    Writeinfile();
                    break;
                case 2:
                    Readfromfile();
                    break;
                default:
                    System.out.println("Wrong choice");
            }
        }
    }

