public class Armstrong {
    public static void main(String[] args) {
        int sum=0,count=0;
        System.out.println("ARMSTRONG NUMBERS ARE: " );
        for(int i=2;i<1000;i++)
        {
            int num=i;
            while(num>0) {
                int m = num % 10;
                sum= sum + (m*m*m);
                num /= 10;
            }
            if (sum==i) {
                System.out.print(i + " ");
                count++;
            }
            sum=0;
        }
        System.out.println("count: "+count);
    }
}
