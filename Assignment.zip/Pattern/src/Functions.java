import java.util.*;
public class Functions {
    public static int sum(int m, int n) {
        int sum = m + n;
        return sum;
    }
    public static void multiplication(int m,int n) {
    int product=m*n;
        System.out.println("Multiplication of two numbers is : " + product);
    }
    public static int division() {
    int m=10, n=2;
    int div=m/n;
    return div;
    }
    public static void subtraction() {
    int m=10, n=2;
    int sub=m-n;
    System.out.println("Subtraction of two numbers is : " +sub);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter first number: ");
        int m = sc.nextInt();
        System.out.println("Enter second number: ");
        int n = sc.nextInt();
        int add=sum(m,n);
        System.out.println("Addition of two numbers is : " +add);
        multiplication(m,n);
        int div=division();
        System.out.println("Division of two numbers is : " +div);
        subtraction();
    }
}

