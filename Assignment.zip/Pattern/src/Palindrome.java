import java.util.*;
public class Palindrome {
    public static void main(String [] args)
    {
        int rev=0;
        int count=0;
        System.out.println("PALINDROME NUMBERS ARE: " );
        for(int i=11;i<1000;i++)
        {
           int num=i;
            while(num>0) {
                int rem = num % 10;
                rev = (rev * 10) + rem;
                num /= 10;
            }
                if (rev==i) {
                    System.out.print(i + " ");
                    count++;
                }
                rev=0;
        }
        System.out.println("count: "+count);
    }
}
