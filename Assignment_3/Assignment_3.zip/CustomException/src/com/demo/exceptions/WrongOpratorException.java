package com.demo.exceptions;

public class WrongOpratorException extends Exception{


    public WrongOpratorException(String s) {
        System.out.println(s);

    }
}
