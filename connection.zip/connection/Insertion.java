package com.mysql.connection;
import com.mysql.jdbc.Driver;

import java.sql.*;
import java.util.Scanner;

public class Insertion {
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            //DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
            String url="jdbc:mysql://localhost:3306/jdbc";
            // String url="jdbc:mysql://localhost:3306/jdbc?allowPublicKeyRetrieval=true&useSSL=false";
            String username="root";
            String password="tiger";
            Connection con=DriverManager.getConnection(url,username,password);
            Scanner sc =new Scanner (System.in);
            System.out.println("Enter employee ID number");
            int q=sc.nextInt();
            System.out.println("Enter employee Name ");
            String w=sc.next();
            System.out.println("Enter employee city of residency");
            String e=sc.next();
            System.out.println("Enter employee Blood Group");
            String r=sc.next();
            String query="INSERT INTO empdata(emp_id,emp_name,emp_city,emp_bg)" + "VALUES(?,?,?,?)";
            //select * from empdata;
            PreparedStatement ps= con.prepareStatement(query);
            ps.setInt(1,q);
            ps.setString(2,w);
            ps.setString(3,e);
            ps.setString(4,r);

            int i=ps.executeUpdate();
            if(i>0)
            {
                System.out.println("pass");
            }
            else {
                System.out.println("fail");
            }
            con.close();
        }  catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

}
