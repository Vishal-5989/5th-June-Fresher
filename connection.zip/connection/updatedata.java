package com.mysql.connection;
import com.mysql.jdbc.Driver;

import java.sql.*;
import java.util.Scanner;

public class updatedata {
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            String url="jdbc:mysql://localhost:3306/jdbc";

            String username="root";
            String password="tiger";
            Connection con=DriverManager.getConnection(url,username,password);
            Scanner sc=new Scanner(System.in);

            System.out.println("Enter id to update the record: ");
            int a=sc.nextInt();
            System.out.println("Enter city to update record: ");
            String ac=sc.next();
            String query="update empdata set emp_city=? where emp_id=?";
            PreparedStatement ps= con.prepareStatement(query);
            ps.setString(1,ac);
            ps.setInt(2,a);

            ps.executeUpdate();
            // int i=ps.executeUpdate();
            System.out.println("Record has been updated!!");

            con.close();
        }  catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

}


