package com.mysql.connection;
import com.mysql.jdbc.Driver;

import java.sql.*;

public class Connection1 {
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            //DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
            String url="jdbc:mysql://localhost:3306/jdbc";
           // String url="jdbc:mysql://localhost:3306/jdbc?allowPublicKeyRetrieval=true&useSSL=false";
            String username="root";
            String password="tiger";
            Connection con=DriverManager.getConnection(url,username,password);
            String query="select * from empdata";
            PreparedStatement ps= con.prepareStatement(query);
            ResultSet rs=ps.executeQuery(query);
            while(rs.next())
            {
                System.out.println("ID= "+rs.getInt(1));
                System.out.println("NAME= "+rs.getString(2));
                System.out.println("CITY= "+rs.getString(3));
                System.out.println("BLOOD GROUP= "+rs.getString(4));
            }

            con.close();
        }  catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

}
