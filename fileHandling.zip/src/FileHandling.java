import jdk.jfr.StackTrace;

import java.io.*;
import java.util.Scanner;

public class FileHandling {
    public static void main(String[] args) throws IOException {
        FileHandling fh = new FileHandling();
        fh.createFile();
        System.out.println("Enter 1.write file 2. read file ");
        System.out.println("enter the choice: ");
        Scanner sc=new Scanner(System.in);
        int op=sc.nextInt();
        switch(op)
        {
            case 1:fh.fileWrite();break;
            case 2:fh.fileRead();break;
            default:
                System.out.println("You have entred wrong choice!!!");
        }
    }

    public void createFile() {
        try {
            File f = new File("C:\\Users\\NTS-AishwaryaShinde\\Documents\\fileHandling.txt");
            if (f.createNewFile()) {
                System.out.println("File " + f.getName() + " is succesfuly created.");
            } else {
                System.out.println("File is already exits in directory!!!");
            }
        } catch (IOException e) {
            System.out.println("Unexpected Error");
            e.printStackTrace();
        }
    }

    public void fileWrite() throws IOException {
        FileWriter fw = new FileWriter("C:\\Users\\NTS-AishwaryaShinde\\Documents\\fileHandling.txt");
        fw.write("Selfless Good Deed");
        fw.close();
        System.out.println("Content is written succesfully.");
    }

    public void fileRead() throws IOException {
        FileReader fr = new FileReader("C:\\Users\\NTS-AishwaryaShinde\\Documents\\fileHandling.txt");
        int i;
        while ((i=fr.read())!=-1)
            System.out.print((char)i);
            fr.close();

    }
}
