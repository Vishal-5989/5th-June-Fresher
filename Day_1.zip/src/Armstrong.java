import java.util.Scanner;

public class Armstrong {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        // System.out.println("Enter the range:");
        //int num1=sc.nextInt();
        // int num2=sc.nextInt();
        int sum=0 ,count=0;
        for(int i=1;i<1000;i++)
        {
            int n=i;
            while(n>0) {
                int a = n % 10;
                sum = sum+(a*a*a);
                n /= 10;
            }
            if(i == sum)
            {
                count++;
                System.out.print( sum+" ");
            }
            sum=0;
        }
        System.out.println(" ");
        System.out.println("Count= "+ count);

    }
}
