import java.util.*;
public class Palindrome {
    public static void main(String [] args)
    {
        Scanner sc=new Scanner(System.in);
       // System.out.println("Enter the range:");
        //int num1=sc.nextInt();
       // int num2=sc.nextInt();
        int rev=0 ,count=0;
        for(int i=10;i<1000;i++)
        {
           int n=i;
            while(n>0) {
                int rem = n % 10;
                rev = (rev * 10) + rem;
                n = n/ 10;
            }
            if(i == rev)
            {
                count++;
                System.out.print( rev+" ");
            }
            rev=0;
        }
        System.out.println(" ");
        System.out.println("Count= "+ count);


    }
}
