import java.util.*;
public class Fibonacci {
    public static void main(String [] args)
    {
        int x=0,y=1,sum=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number: ");
        int num=sc.nextInt();
        System.out.println("Fibonacci series:");
        for(int i=1; i<=num;i++)
        {
            System.out.print(x +"  ");
            sum=x+y;
            x=y;
            y=sum;
        }
    }
}
