import java.util.*;
public class Methods {

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter first number: ");
        int n1=sc.nextInt();
        System.out.println("Enter second number: ");
        int n2=sc.nextInt();
        int ans=sum(n1,n2);
        System.out.println("Addition of two numbers is  "+ ans);
        substraction(n1,n2);
        int product=multiplication();
        System.out.println("Multiplication of two numbers is  "+ product);
        division();
    }
    public static int sum(int n1,int n2)
    {
        int add=n1+n2;
        return add;
    }

    public static void substraction(int a,int b)
    {
        int sub=a-b;
        System.out.println("Substraction of two numbers is "+ sub);
    }

   public static int multiplication()
    {
        int a=10,b=20;
        int product= a*b;
        return product;
    }

    public static void division()
    {
        int a=100,b=20;
        int div= a/b;
        System.out.println("Division of two numbers "+ div);
    }



}
