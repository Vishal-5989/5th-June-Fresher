package com.mysql.connection;

import java.sql.*;
import java.util.Scanner;

public class Empdata {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter 1. SPECIAL OPERATOR 2.SUBQUERY OPERATOR 3.CLAUSES 4.JOINS");
        System.out.println("Enter choice: ");
        int op=sc.nextInt();
        switch (op)
        {
            case 1:
                System.out.println("Enter 1. IN  2.NOT IN 3.BETWEEN 4.NOT BETWEEN 5.IS  6.IS NOT 7.LIKE 8.NOT LIKE");
                System.out.println("Enter choice: ");
                int choice=sc.nextInt();
                switch(choice)
                {
                    case 1:
                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            String url = "jdbc:mysql://localhost:3306/EMPDETAILS";
                            String username = "root";
                            String password = "tiger";
                            Connection con = DriverManager.getConnection(url, username, password);
                            System.out.println("Details of employee along with annual salary for employee working as appdev AND devops and annual salary greater then 500000");
                            PreparedStatement ps = con.prepareStatement("SELECT EMP_NAME, EMP_SAL*12 AS ANNUAL_SAL FROM NTSEMP1 WHERE EMP_DEPT IN('APPDEV','DEVOPS') AND EMP_SAL*12 >500000");
                            ResultSet rs = ps.executeQuery();
                            System.out.println("NAME OF THE EMPLOYEES WORKING IN APPDEV AND DEVOPS DEPARTMENT AND THEIR ANNUAL SALARY IS");
                            while(rs.next())
                            {
                                System.out.println(rs.getString(1)+ "   " +  rs.getInt(2));

                            }

                            con.close();
                        }
                        catch (SQLException e) {
                            throw new RuntimeException(e);
                        } catch (ClassNotFoundException e) {
                            throw new RuntimeException(e);
                        }
                        break;
                    case 2:

                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDETAILS","root" ,"tiger" );
                            System.out.println("Details of employee along with annual salary for employee NOT working IN QA  and IT");
                            PreparedStatement ps = con.prepareStatement("SELECT  NTSEMP1.*, EMP_SAL*12 AS ANNUAL_SAL FROM NTSEMP1 WHERE EMP_DEPT NOT IN('IT','QA')");
                            ResultSet rs = ps.executeQuery();
                            while(rs.next())
                            {
                                System.out.println(rs.getString(1)+ "    "+rs.getString(2)+ "    " + rs.getString(3)+ "    " +  rs.getInt(4) +"    " +  rs.getInt(5)+"    " +rs.getString(6) +"    "+rs.getInt(7));

                            }

                            con.close();
                        }
                        catch (SQLException e) {
                            throw new RuntimeException(e);
                        } catch (ClassNotFoundException e) {
                            throw new RuntimeException(e);
                        }
                        break;

                    case 3:

                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDETAILS","root" ,"tiger" );
                            System.out.println("NAME of employee along with salary for employee SALARY between 40000 to 50000");
                            PreparedStatement ps = con.prepareStatement("SELECT EMP_NAME,EMP_SAL FROM NTSEMP1 WHERE EMP_SAL BETWEEN 40000 AND 50000");
                            ResultSet rs = ps.executeQuery();

                            while(rs.next())
                            {
                                System.out.println(rs.getString(1)+  "    " +  rs.getInt(2) );

                            }

                            con.close();
                        }
                        catch (SQLException e) {
                            throw new RuntimeException(e);
                        } catch (ClassNotFoundException e) {
                            throw new RuntimeException(e);
                        }
                        break;

                    case 4:

                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDETAILS","root" ,"tiger" );
                            System.out.println("NAME of employee along with salary for employee SALARY NOT between 40000 to 50000");
                            PreparedStatement ps = con.prepareStatement("SELECT EMP_NAME,EMP_SAL FROM NTSEMP1 WHERE EMP_SAL NOT BETWEEN 40000 AND 50000");
                            ResultSet rs = ps.executeQuery();

                            while(rs.next())
                            {
                                System.out.println(rs.getString(1)+  "    " +  rs.getInt(2) );

                            }

                            con.close();
                        }
                        catch (SQLException e) {
                            throw new RuntimeException(e);
                        } catch (ClassNotFoundException e) {
                            throw new RuntimeException(e);
                        }
                        break;

                    case 5:

                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDETAILS","root" ,"tiger" );
                            System.out.println("NAME of employee  for employee SALARY is NULL");
                            PreparedStatement ps = con.prepareStatement("SELECT EMP_NAME,EMP_SAL FROM NTSEMP1 WHERE EMP_SAL IS NULL");
                            ResultSet rs = ps.executeQuery();

                            while(rs.next())
                            {
                                System.out.println(rs.getString(1) );

                            }

                            con.close();
                        }
                        catch (SQLException e) {
                            throw new RuntimeException(e);
                        } catch (ClassNotFoundException e) {
                            throw new RuntimeException(e);
                        }
                        break;

                    case 6:

                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDETAILS","root" ,"tiger" );
                            System.out.println("NAME of employee  for employee SALARY is NOTNULL");
                            PreparedStatement ps = con.prepareStatement("SELECT EMP_NAME,EMP_SAL FROM NTSEMP1 WHERE EMP_SAL IS NOT NULL");
                            ResultSet rs = ps.executeQuery();

                            while(rs.next())
                            {
                                System.out.println(rs.getString(1)+  "    " +  rs.getInt(2) );

                            }

                            con.close();
                        }
                        catch (SQLException e) {
                            throw new RuntimeException(e);
                        } catch (ClassNotFoundException e) {
                            throw new RuntimeException(e);
                        }
                        break;

                    case 7:

                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDETAILS","root" ,"tiger" );
                            System.out.println("NAME of employee whose name starts with 'A' or 'E' ");
                            PreparedStatement ps = con.prepareStatement("SELECT EMP_NAME FROM NTSEMP1 WHERE EMP_NAME LIKE 'A%' OR EMP_NAME LIKE 'E%'");
                            ResultSet rs = ps.executeQuery();

                            while(rs.next())
                            {
                                System.out.println(rs.getString(1) );

                            }

                            con.close();
                        }
                        catch (SQLException e) {
                            throw new RuntimeException(e);
                        } catch (ClassNotFoundException e) {
                            throw new RuntimeException(e);
                        }
                        break;

                    case 8:

                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDETAILS","root" ,"tiger" );
                            System.out.println("NAME of employee whose name does not start with 'A' and does not end with 'E'");
                            PreparedStatement ps = con.prepareStatement("SELECT EMP_NAME FROM NTSEMP1 WHERE EMP_NAME NOT LIKE 'A%E' ");
                            ResultSet rs = ps.executeQuery();

                            while(rs.next())
                            {
                                System.out.println(rs.getString(1) );

                            }

                            con.close();
                        }
                        catch (SQLException e) {
                            throw new RuntimeException(e);
                        } catch (ClassNotFoundException e) {
                            throw new RuntimeException(e);
                        }
                        break;
                }
                break;
            case 2:

                System.out.println("Enter 1. ALL  2.ANY ");
                System.out.println("Enter CHOICE: ");
                int OP1=sc.nextInt();
                switch(OP1)
                {
                    case 1:
                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDETAILS","root" ,"tiger" );
                            System.out.println("NAME of employee whose salary is more than QA");
                            PreparedStatement ps = con.prepareStatement("SELECT EMP_NAME,EMP_SAL FROM NTSEMP1 WHERE EMP_SAL > ALL(SELECT EMP_SAL FROM NTSEMP1 WHERE EMP_DEPT = 'QA') ");
                            ResultSet rs = ps.executeQuery();

                            while(rs.next())
                            {
                                System.out.println(rs.getString(1)+  "    " +  rs.getInt(2) );

                            }

                            con.close();
                        }
                        catch (SQLException e) {
                            throw new RuntimeException(e);
                        } catch (ClassNotFoundException e) {
                            throw new RuntimeException(e);
                        }
                        break;


                    case 2:

                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDETAILS","root" ,"tiger" );
                            System.out.println("NAME of employee who are working in  is more than QA");
                            PreparedStatement ps = con.prepareStatement("SELECT EMP_NAME,EMP_SAL,EMP_DEPT FROM NTSEMP1 WHERE EMP_DEPT = ANY(SELECT EMP_DEPT FROM NTSEMP1 WHERE EMP_SAL >40000) ");
                            ResultSet rs = ps.executeQuery();

                            while(rs.next())
                            {
                                System.out.println(rs.getString(1)+  "    " +  rs.getInt(2) +"  "+rs.getString(1) );

                            }

                            con.close();
                        }
                        catch (SQLException e) {
                            throw new RuntimeException(e);
                        } catch (ClassNotFoundException e) {
                            throw new RuntimeException(e);
                        }
                        break;
                }
                break;

            case 3:
                System.out.println("Enter 1.GROUP BY  2.HAVING 3.ORDER BY ");
                System.out.println("Enter CHOICE: ");
                int h=sc.nextInt();
                switch(h)
                {
                    case 1:
                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDETAILS","root" ,"tiger" );
                            System.out.println("NAME of employee who are having maximum salary given to each department");
                            PreparedStatement ps = con.prepareStatement("SELECT MAX(EMP_SAL), EMP_DEPT FROM NTSEMP1 GROUP BY EMP_DEPT ");
                            ResultSet rs = ps.executeQuery();

                            while(rs.next())
                            {
                                System.out.println(  rs.getInt(1) +" "+ rs.getString(2) );

                            }

                            con.close();
                        }
                        catch (SQLException e) {
                            throw new RuntimeException(e);
                        } catch (ClassNotFoundException e) {
                            throw new RuntimeException(e);
                        }

                        break;

                    case 2:

                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDETAILS","root" ,"tiger" );
                            System.out.println("NAME of employee who are having DUPLICATE salary.");
                            PreparedStatement ps = con.prepareStatement("SELECT EMP_SAL FROM NTSEMP1 GROUP BY EMP_SAL HAVING COUNT(*)>1 ");
                            ResultSet rs = ps.executeQuery();

                            while(rs.next())
                            {
                                System.out.println(rs.getInt(1));

                            }

                            con.close();
                        }
                        catch (SQLException e) {
                            throw new RuntimeException(e);
                        } catch (ClassNotFoundException e) {
                            throw new RuntimeException(e);
                        }
                        break;

                    case 3:

                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDETAILS","root" ,"tiger" );
                            System.out.println("NAME of employee who are having DUPLICATE salary.");
                            PreparedStatement ps = con.prepareStatement("SELECT EMP_NAME,EMP_SAL FROM NTSEMP1 ORDER BY EMP_SAL DESC");
                            ResultSet rs = ps.executeQuery();

                            while(rs.next())
                            {
                                System.out.println(rs.getString(1) +"  "+rs.getInt(2));

                            }

                            con.close();
                        }
                        catch (SQLException e) {
                            throw new RuntimeException(e);
                        } catch (ClassNotFoundException e) {
                            throw new RuntimeException(e);
                        }
                        break;
                }
                default:
                    System.out.println("YOU HAVE ENTERED WRONG CHOICE!!");
        }
    }
    }



