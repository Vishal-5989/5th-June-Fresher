import java.util.Arrays;

public class Reversestring {
    public static void main(String[] args) {
        String s = "MY NAME IS AK";
        String s1[] = s.split(" ");
        String rev = "";

        for (int i = 0; i < s1.length; i++)
        {
            String s2 = s1[i];
            String rev1 = "";
            for (int j = s2.length() - 1; j >= 0; j--) {
                rev1 = rev1 + s2.charAt(j);
            }
            rev = rev + rev1 + " ";
        }
        System.out.print("Reversed string : " + rev);
        }
    }
