import java.sql.SQLOutput;
import java.util.*;
public class StringMethod {
    public static void main(String[] args) {
        int i = 1;
        Scanner sc = new Scanner(System.in);
        String s = " Happy Me ";
        System.out.println("Enter 1:charAt() 2:equals() 3:isEmpty() 4:replace() 5:inderOf() 6:concate() 7:equalIgnoreCase() 8:length() 9:substring() 10:toLowerCase() 11:toUpperCase() 12:trim() 13:split() 14:toCharArray 15:exit");
        while (i > 0) {
            System.out.println("Enter the value: ");
            int a = sc.nextInt();
            switch (a) {
                case 1:
                    System.out.println("Enter the index value: ");
                    int index = sc.nextInt();
                    char b = s.charAt(index);
                    System.out.println("Character present at " + index + " index value is: " + b);
                    break;
                case 2:
                    System.out.println("Enter two string that u want to check:");
                    System.out.println("Enter first string: ");
                    String s1 = sc.next();
                    System.out.println("Enter second string: ");
                    String s2 = sc.next();
                    System.out.println(s2.equals(s1));
                    break;
                case 3:
                    System.out.println(s.isEmpty());
                    break;
                case 4:
                    System.out.println(s);
                    System.out.println("Replaced String is: " + s.replace("Happy", "Sad"));
                    break;
                case 5:
                    System.out.println(s.indexOf('a'));
                    break;
                case 6:
                    System.out.println(s.concat(" or sad me"));
                    break;
                case 7:
                    String s3 = "HAPPY ME";
                    System.out.println(s.equalsIgnoreCase(s3));
                    break;
                case 8:
                    System.out.println(s.length());
                    break;
                case 9:
                    System.out.println(s.substring(2));
                    break;
                case 10:
                    System.out.println(s.toLowerCase());
                    break;
                case 11:
                    System.out.println(s.toUpperCase());
                    break;
                case 12:
                    System.out.println(s.trim());
                    break;
                case 13:
                    String[] s4 = s.split(" ");
                    System.out.println(Arrays.toString(s4));
                    break;
                case 14:
                    char[] s5 = s.toCharArray();
                    System.out.println(s5);
                    System.out.println(Arrays.toString(s5));
                    break;
                case 15:
                    System.exit(0);
                    break;
                default:
                    System.out.println("wrong value");
                    break;


            }
        }
    }
}