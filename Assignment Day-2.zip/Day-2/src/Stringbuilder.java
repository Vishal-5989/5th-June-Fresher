import java.util.Scanner;

public class Stringbuilder {
    public static void main(String[] args) {
        int i = 1;
        Scanner sc = new Scanner(System.in);
        StringBuilder s = new StringBuilder("Neutrino Tech Labs");
        System.out.println("Enter 1:append() 2:insert() 3:reverse() 4:capacity() 5:ensureCapacity() 6:trimToSize() 7:charAt() 8:setCharAt() 9:delete() 10:deleteCharAt() 11:substring() 12:equals() 13:exit");
        while (i > 0)
        {
            System.out.println("Enter the value: ");
            int a = sc.nextInt();
            switch (a) {
                case 1:
                    System.out.println(s.append(" NTS "));
                    break;
                case 2:
                    System.out.println(s.insert(13," Automation"));
                    break;
                case 3:
                    System.out.println(s.reverse());
                    break;
                case 4:
                    System.out.println(s.capacity());
                    break;
                case 5:
                    System.out.println(s.capacity());
                    s.ensureCapacity(100);
                    System.out.println(s.capacity());
                    break;
                case 6:
                    s.append(12345);
                    System.out.println(s.length());
                    System.out.println(s.capacity());
                    s.trimToSize();
                    System.out.println(s.capacity());
                    break;
                case 7:
                    System.out.println(s.charAt(7));
                    break;
                case 8:
                    s.setCharAt(9,'t');
                    System.out.println(s);
                    break;
                case 9:
                    s.delete(13,17);
                    System.out.println(s);
                    break;
                case 10:
                    s.deleteCharAt(0);
                    System.out.println(s);
                    break;
                case 11:
                    s.substring(9,14);
                    System.out.println(s);
                    break;
                case 12:
                    String s1="Neutrino";
                    System.out.println(s1.equals(s));
                    break;
                case 13:
                    System.exit(0);
                    break;
                default:
                    System.out.println("wrong value");
                    break;
            }
        }
    }
}
