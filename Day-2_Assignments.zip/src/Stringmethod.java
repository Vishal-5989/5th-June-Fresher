import java.sql.SQLOutput;
import java.util.*;
public class Stringmethod{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the String: ");
        String s=sc.nextLine();
        int i=1;
        System.out.println("enter 1.charAT() 2.equals() 3.isEmpty() 4.replace() 5.indexOf() 6.concate() 7.equalIgnorecase() 8.length() 9.substring()  10.toLowerCase() 11.toUpperCase() 12.trim() 13.split() 14.tochararray() 15.toExit");
        while(i>0) {
            System.out.println("Enter the choice: ");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Enter the index: ");
                    int index = sc.nextInt();
                    char b = s.charAt(index);
                    System.out.println(" Character present at " + index + " index is " + b);
                    break;
                case 2:
                    System.out.println("Enter the Strings that you want to compare: ");
                    System.out.println("Enter the first String ");
                    String s1 = sc.next();
                    System.out.println("Enter the second String ");
                    String s2 = sc.next();
                    System.out.println();
                    System.out.println(s2.equals(s1));
                    break;
                case 3:
                    System.out.println(s.isEmpty());
                    break;
                case 4:
                    String v = "Java is Easy";
                    System.out.println(v);
                    v = v.replace("Hard", "Easy");
                    System.out.println(v);
                    break;
                case 5:
                    System.out.println(s.indexOf('a'));
                    break;
                case 6:
                    s = s.concat(" Hello World");
                    System.out.println(s);
                    break;
                case 7:
                    System.out.println("Enter the String ");
                    String s3 = sc.next();
                    System.out.println(s.equalsIgnoreCase(s3));
                    break;
                case 8:
                    System.out.println(s.length());
                    break;
                case 9:
                    System.out.println(s.substring(2));
                    break;
                case 10:
                    System.out.println(s.toLowerCase());
                    break;
                case 11:
                    System.out.println(s.toUpperCase());
                    break;
                case 12:
                    System.out.println(s.trim());
                    break;
                case 13:
                    String[] w = s.split(" ");
                    System.out.println(Arrays.toString(w));
                    break;
                case 14:
                    char[] o = s.toCharArray();
                    System.out.println(Arrays.toString(o));
                    break;
                case 15:
                    System.exit(0);
                default:
                    System.out.println("You have enterd wrong choice");
            }
        }

    }

}
