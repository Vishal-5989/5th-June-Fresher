import java.util.*;
public class Stringreverse {
    public static void main(String[] args) {
        String str = "Neutrino Tech System", nstr = "";
        String[] a = str.split(" ");
        for (int i=0; i<a.length; i++)
        {
            String s=a[i];
            String nnstr= "";
            for(int j=s.length()-1;j>=0;j--) {
                nnstr=nnstr+s.charAt(j);
            }
            nstr = nstr + nnstr+ " ";
        }
        System.out.println("Reversed word: "+ nstr);
    }
    }

