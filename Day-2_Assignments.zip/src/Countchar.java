import java.util.*;
public class Countchar {
    public static void main(String[] args) {
        String s="neutrino tech system";
        int count;
        char ch[]=s.toCharArray();
        System.out.println("Number of occurence of character : ");

        for(int i=0; i<ch.length; i++)
        {
            count=1;
            for(int j=i+1 ;j<ch.length;j++)
            {
                if(ch[i]== ch[j]&& ch[i]!=' ')
                {
                    count++;
                    ch[j] ='0';
                }
            }
            if(ch[i]!='0')
            {
                System.out.println("The occurrence of "+ch[i]+ "=" +count);
            }
        }
    }
}
