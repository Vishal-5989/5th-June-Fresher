import java.util.*;
public class Stringbuffermethods {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        StringBuffer s=new StringBuffer("Hello Neutrino");
        System.out.println(s);
        int i=1;
        System.out.println("enter 1.append() 2.insert() 3.reverse() 4.capacity() 5.ensureCapacity() 6.trimToSize() 7.charAt() 8.setCharAt() 9.delete()  10.deleteCharAt() 11.substring() 13.toExit");
        while(i>0) {
            System.out.println("Enter the choice: ");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    s.append(" Tech System");
                    System.out.println(s);
                    break;
                case 2:
                    s.insert(1," Tech System");
                    System.out.println(s);
                    break;
                case 3:
                    s.reverse();
                    System.out.println(s);
                    break;
                case 4:
                    System.out.println( s.capacity());

                    break;
                case 5:
                    System.out.println( s.capacity());
                    s.ensureCapacity(100);
                    System.out.println( s.capacity());
                    break;
                case 6:
                   s.append(12345678);
                    System.out.println(s.length());
                    System.out.println(s.capacity());
                    s.trimToSize();
                    System.out.println(s.capacity());
                    break;
                case 7:
                    System.out.println(s);

                    char b = s.charAt(6);
                    System.out.println(" Character present at 6th  index is " + b);
                    break;
                case 8:
                    System.out.println(s);
                    s.setCharAt(0,'h');
                    System.out.println(s);
                    break;
                case 9:
                    s.delete(0,5);
                    System.out.println(s);
                    break;
                case 10:
                    s.deleteCharAt(3);
                    System.out.println(s);
                    break;
                case 11:
                    System.out.println(s);
                    System.out.println(s.substring(2,7));
                    break;
                case 13:
                    System.exit(0); break;
                default:
                    System.out.println("You have enterd wrong choice");
            }
        }

    }
}
