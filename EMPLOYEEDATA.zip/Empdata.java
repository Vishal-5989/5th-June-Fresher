import java.sql.*;
import java.util.Scanner;

public class Empdata {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter value 1:SPECIAL OPERATOR 2:SUB-QUERY OPERATOR 3:Clauses 4:JOINS");
        int a = sc.nextInt();
        switch (a) {
            case 1:
                System.out.println("Enter 1:IN 2:NOT IN 3:BETWEEN 4:NOT BETWEEN 5:IS 6:IS NOT 7:LIKE 8:NOT LIKE");
                int b = sc.nextInt();
                switch (b) {
                    case 1:
                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDATA", "root", "Tiger");
                            PreparedStatement ps = conn.prepareStatement("SELECT EMP_NAME,EMP_SAL*12 AS AVG_SAL FROM EMPLOYEEDATA WHERE EMP_DEPT IN('QA','APP DEV') AND EMP_SAL*12>400000");
                            ResultSet rs=ps.executeQuery();
                            System.out.println("NAME OF EMPLOYEE:  AND AVERAGE SALARY IS: ");
                            while(rs.next())
                            {
                                System.out.println(rs.getString(1) + "  "+ rs.getInt(2));
                            }
                            conn.close();
                        } catch (ClassNotFoundException ex) {
                            ex.printStackTrace();
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                        break;
                    case 2:
                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDATA", "root", "Tiger");
                            PreparedStatement ps = conn.prepareStatement("SELECT EMPLOYEEDATA.*, EMP_SAL*12 AS AVG_SAL FROM EMPLOYEEDATA WHERE EMP_DEPT NOT IN('IT','QA')");
                            ResultSet rs=ps.executeQuery();
                            System.out.println("DETAILS OF EMPLOYEE: ");
                            while(rs.next())
                            {
                                System.out.println( rs.getString(1)+"  "+ rs.getString(2) + "  "+ rs.getString(3) + "  "+ rs.getInt(4)+"  " + rs.getInt(5)+"  "+ rs.getString(6)+ "  "+ rs.getInt(7) );
                            }
                            conn.close();
                        } catch (ClassNotFoundException ex) {
                            ex.printStackTrace();
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                        break;
                    case 3:
                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDATA", "root", "Tiger");
                            PreparedStatement ps = conn.prepareStatement("SELECT EMP_NAME,EMP_SAL FROM EMPLOYEEDATA WHERE EMP_SAL BETWEEN 40000 AND 50000");
                            ResultSet rs=ps.executeQuery();
                            System.out.println("DETAILS OF EMPLOYEE: ");
                            while(rs.next())
                            {
                                System.out.println( rs.getString(1)+"  "+  rs.getInt(2));
                            }
                            conn.close();
                        } catch (ClassNotFoundException ex) {
                            ex.printStackTrace();
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                        break;
                    case 4:
                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDATA", "root", "Tiger");
                            PreparedStatement ps = conn.prepareStatement("SELECT EMP_NAME,EMP_SAL FROM EMPLOYEEDATA WHERE EMP_SAL NOT BETWEEN 40000 AND 50000");
                            ResultSet rs=ps.executeQuery();
                            System.out.println("DETAILS OF EMPLOYEE: ");
                            while(rs.next())
                            {
                                System.out.println( rs.getString(1)+"  "+  rs.getInt(2));
                            }
                            conn.close();
                        } catch (ClassNotFoundException ex) {
                            ex.printStackTrace();
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                        break;
                    case 5:
                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDATA", "root", "Tiger");
                            PreparedStatement ps = conn.prepareStatement("SELECT EMP_NAME FROM EMPLOYEEDATA WHERE EMP_SAL IS NULL");
                            ResultSet rs=ps.executeQuery();
                            System.out.println("DETAILS OF EMPLOYEE: ");
                            while(rs.next())
                            {
                                System.out.println( rs.getString(1));
                            }
                            conn.close();
                        } catch (ClassNotFoundException ex) {
                            ex.printStackTrace();
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                        break;
                    case 6:
                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDATA", "root", "Tiger");
                            PreparedStatement ps = conn.prepareStatement("SELECT EMP_NAME FROM EMPLOYEEDATA WHERE EMP_SAL IS NOT NULL");
                            ResultSet rs=ps.executeQuery();
                            System.out.println("DETAILS OF EMPLOYEE: ");
                            while(rs.next())
                            {
                                System.out.println( rs.getString(1));
                            }
                            conn.close();
                        } catch (ClassNotFoundException ex) {
                            ex.printStackTrace();
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                        break;
                    case 7:
                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDATA", "root", "Tiger");
                            PreparedStatement ps = conn.prepareStatement("SELECT EMP_NAME FROM EMPLOYEEDATA WHERE EMP_NAME LIKE 'A%' ");
                            ResultSet rs=ps.executeQuery();
                            System.out.println("DETAILS OF EMPLOYEE: ");
                            while(rs.next())
                            {
                                System.out.println( rs.getString(1));
                            }
                            conn.close();
                        } catch (ClassNotFoundException ex) {
                            ex.printStackTrace();
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                        break;
                    case 8:
                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDATA", "root", "Tiger");
                            PreparedStatement ps = conn.prepareStatement("SELECT EMP_NAME FROM EMPLOYEEDATA WHERE EMP_NAME NOT LIKE '%H' ");
                            ResultSet rs=ps.executeQuery();
                            System.out.println("DETAILS OF EMPLOYEE: ");
                            while(rs.next())
                            {
                                System.out.println( rs.getString(1));
                            }
                            conn.close();
                        } catch (ClassNotFoundException ex) {
                            ex.printStackTrace();
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                        break;
                }
                break;
            case 2:
                System.out.println("Enter 1:ALL 2:ANY 3:EXISTS 4:NOT EXISTS");
                int c=sc.nextInt();
                switch(c)
                {
                    case 1:
                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDATA", "root", "Tiger");
                            PreparedStatement ps = conn.prepareStatement("SELECT EMP_NAME, EMP_SAL FROM EMPLOYEEDATA WHERE EMP_SAL > ALL(SELECT EMP_SAL FROM EMPLOYEEDATA WHERE EMP_DEPT='DEVOPS') ");
                            ResultSet rs=ps.executeQuery();
                            while(rs.next())
                            {
                                System.out.println(rs.getString(1) + "  "+ rs.getInt(2));
                            }
                            conn.close();
                        } catch (ClassNotFoundException ex) {
                            ex.printStackTrace();
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                        break;
                    case 2:
                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDATA", "root", "Tiger");
                            PreparedStatement ps = conn.prepareStatement("SELECT EMP_NAME, EMP_SAL, EMP_DEPT FROM EMPLOYEEDATA WHERE EMP_DEPT=ANY(SELECT EMP_DEPT FROM EMPLOYEEDATA WHERE EMP_SAL>40000) ");
                            ResultSet rs=ps.executeQuery();
                            while(rs.next())
                            {
                                System.out.println(rs.getString(1) + "  "+ rs.getInt(2)+ " "+ rs.getString(3));
                            }
                            conn.close();
                        } catch (ClassNotFoundException ex) {
                            ex.printStackTrace();
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                        break;
                    case 3:
                        break;
                }
                break;
            case 3:
                System.out.println("Enter 1:GROUP BY 2:HAVING 3:ORDER BY");
                int d=sc.nextInt();
                switch(d) {
                    case 1:
                    try {
                        Class.forName("com.mysql.cj.jdbc.Driver");
                        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDATA", "root", "Tiger");
                        PreparedStatement ps = conn.prepareStatement("SELECT MAX(EMP_SAL), EMP_DEPT FROM EMPLOYEEDATA GROUP BY EMP_DEPT");
                        ResultSet rs = ps.executeQuery();
                        while (rs.next()) {
                            System.out.println(rs.getInt(1)+" "+ rs.getString(2));
                        }
                        conn.close();
                    } catch (ClassNotFoundException ex) {
                        ex.printStackTrace();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                    break;
                    case 2:
                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDATA", "root", "Tiger");
                            PreparedStatement ps = conn.prepareStatement("SELECT  EMP_SAL FROM EMPLOYEEDATA GROUP BY EMP_SAL HAVING COUNT(*)>1");
                            ResultSet rs=ps.executeQuery();
                            while(rs.next())
                            {
                                System.out.println( rs.getInt(1));
                            }
                            conn.close();
                        } catch (ClassNotFoundException ex) {
                            ex.printStackTrace();
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                        break;
                    case 3:
                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDATA", "root", "Tiger");
                            PreparedStatement ps = conn.prepareStatement("SELECT EMP_NAME, EMP_SAL FROM EMPLOYEEDATA ORDER BY EMP_SAL DESC");
                            ResultSet rs=ps.executeQuery();
                            while(rs.next())
                            {
                                System.out.println(rs.getString(1) + "  "+ rs.getInt(2));
                            }
                            conn.close();
                        } catch (ClassNotFoundException ex) {
                            ex.printStackTrace();
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                        break;
                }
            case 4:
                System.out.println("Enter 1:CARTESIAN JOIN 2:SELF JOIN 3:OUTER JOIN");
                int e=sc.nextInt();
                switch(e)
                {
                    case 1:
                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDATA", "root", "Tiger");
                            PreparedStatement ps = conn.prepareStatement("SELECT EMP_NAME, DEPT.ENAME FROM EMPLOYEEDATA ,DEPT WHERE EMPLOYEEDATA.EMP_DEPT=DEPT.EMP_DEPT AND ENAME LIKE '%A%' ");
                            ResultSet rs=ps.executeQuery();
                            while(rs.next())
                            {
                                System.out.println(rs.getString(1) + "  "+ rs.getString(2));
                            }
                            conn.close();
                        } catch (ClassNotFoundException ex) {
                            ex.printStackTrace();
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                        break;
                    case 2:
                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDATA", "root", "Tiger");
                            PreparedStatement ps = conn.prepareStatement("SELECT E.EMP_NAME, D.ENAME FROM EMPLOYEEDATA E , DEPT D WHERE E.EMP_DEPT=D.EMP_DEPT AND D.EMP_DEPT='DEVOPS' ");
                            ResultSet rs=ps.executeQuery();
                            while(rs.next())
                            {
                                System.out.println(rs.getString(1) + "  "+ rs.getString(2));
                            }
                            conn.close();
                        } catch (ClassNotFoundException ex) {
                            ex.printStackTrace();
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                        break;
                    case 3:
                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/EMPDATA", "root", "Tiger");
                            PreparedStatement ps = conn.prepareStatement("SELECT EMP_NAME FROM EMPLOYEEDATA WHERE EMP_DEPT IN(SELECT EMP_DEPT FROM DEPT WHERE ENAME IS NOT NULL)");
                            ResultSet rs=ps.executeQuery();
                            while(rs.next())
                            {
                                System.out.println(rs.getString(1) );
                            }
                            conn.close();
                        } catch (ClassNotFoundException ex) {
                            ex.printStackTrace();
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                        break;
                }
                break;
        }
    }
}
