public class Paircount {
    public static void main(String[] args) {
          String a[]={"(AK,SS)","(AK,AS)","(AK,AM)","(AK,SD)","(AK,AS)","(AK,PT)","(AK,AM)"};
          for(int i=0;i<a.length;i++)
          {
              int count=1;
              for(int j=i+1;j<a.length;j++)
              {
                  if(a[i].equals(a[j]))
                  {
                      count++;
                      System.out.println(a[i]+ "=" + count);
                  }
              }
              count=1;
          }
    }
}
