public class Primenumber {
    public static void main(String[] args) {
        int num=0;
        int count=0;
        for(int i=1;i<=1000;i++)
        {
            int counter=0;
            for(num=i;num>=1;num--)
            {
                if(i%num==0) {
                    counter = counter + 1;
                }
            }
            if(counter==2)
            {
                System.out.print("Prime numbers from 1 to 1000 are: " + i + " ");
                count++;
            }
        }
        System.out.println("Count: "+ count);
    }
}
