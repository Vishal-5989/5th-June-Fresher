import java.util.*;
public class Circle {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter radius: ");
        float r = sc.nextFloat();
        double pii = 3.14;
        int i = 1;
        while (i > 0) {
            System.out.println("Enter 1:Area 2:Circumference 3:exit ");
            int a = sc.nextInt();
            switch (a) {
                case 1:
                    double Area = pii * r * r;
                    System.out.println("Area of Circle: " + Area);
                    break;
                case 2:
                    double Circumference = 2 * pii * r;
                    System.out.println("Circumference of Circle: " + Circumference);
                    break;
                case 3:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Wrong choice");
            }
        }
    }
}
