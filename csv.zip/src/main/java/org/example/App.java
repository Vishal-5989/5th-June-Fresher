package org.example;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class App 
{
    public static void main( String[] args )
    {
        writecsv();
        raadcsv();
    }
    public static void writecsv()
    {
        File f=new File("C:\\Users\\NTS-AishwaryaShinde\\IdeaProjects\\mavenhandling\\src\\main\\data.csv");
        try {

            FileWriter outputfile = new FileWriter(f);

            CSVWriter writer = new CSVWriter(outputfile);

            String[] header = { "Name", "Class", "Marks" };
            writer.writeNext(header);

            String[] data1 = { "ram", "10", "620" };
            writer.writeNext(data1);
            String[] data2 = { "Siya", "20", "567" };
            writer.writeNext(data2);
            String[] data3 = { "lakshy", "30", "890" };
            writer.writeNext(data3);

            writer.close();
        }
        catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public static void raadcsv()
    {
        try {
            FileReader filereader = new FileReader("C:\\Users\\NTS-AishwaryaShinde\\IdeaProjects\\mavenhandling\\src\\main\\data.csv");

            CSVReader csvReader = new CSVReader(filereader);
            String[] nextRecord;

            while ((nextRecord = csvReader.readNext()) != null) {
                for (String cell : nextRecord) {
                    System.out.print(cell + "\t");
                }
                System.out.println();
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
